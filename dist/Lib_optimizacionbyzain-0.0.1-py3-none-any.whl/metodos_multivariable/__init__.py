from .caminata_aleatoria import met_random_walk
from .nelder_mead_simplex import simplex_search_meth
from .met_hooke_jeeves import hooke_jeeves
from .met_cauchy import cauchy
from .met_fletcher_reeves import fletcher_reeves
from .met_newton import newton_method