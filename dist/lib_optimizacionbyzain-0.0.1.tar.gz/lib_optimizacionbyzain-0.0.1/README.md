# Paqueteria de metodos de optimizacion

Esta libreria tiene distintos metodos que son utilizados para la optimizacion
en el encontraras metodos para funciones de una variable y metodos para funciones multivariable